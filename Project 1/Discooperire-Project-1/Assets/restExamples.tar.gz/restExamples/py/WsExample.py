#!/bin/python

#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open 
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may 
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or 
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at 
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the 
# following below this NOSA HEADER, with the fields enclosed by 
# brackets "[]" replaced with your own identifying information: 
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2013-2014 United States Government as represented by 
# the National Aeronautics and Space Administration. No copyright is 
# claimed in the United States under Title 17, U.S.Code. All Other 
# Rights Reserved.
#

import httplib2
import platform
import xml.etree.ElementTree as ET

endpoint = "https://sscweb.sci.gsfc.nasa.gov/WS/sscr/2/"
client = httplib2.Http(".cache")

userAgent = 'WsExample.py (' + platform.python_implementation() + ' ' + platform.python_version() + '; '+ platform.platform() + ')'

requestHeaders = {'Content-Type' : 'application/xml',
                  'User-Agent' : userAgent}

headers, xml = client.request(endpoint + "observatories", "GET",
                              headers=requestHeaders)

#print "%s" % xml

doc = ET.fromstring(xml)

for observatory in doc.findall('{http://sscweb.gsfc.nasa.gov/schema}Observatory'):
    id = observatory.find('{http://sscweb.gsfc.nasa.gov/schema}Id').text
    name = observatory.find('{http://sscweb.gsfc.nasa.gov/schema}Name').text
    print id, name


builder = ET.TreeBuilder()
builder.start('DataRequest', {'xmlns': 'http://sscweb.gsfc.nasa.gov/schema'})
builder.start('TimeInterval', {})
builder.start('Start', {})
builder.data('2008-01-02T11:00:00Z')
builder.end('Start')
builder.start('End', {})
builder.data('2008-01-02T11:01:00')
builder.end('End')
builder.end('TimeInterval')

for sat in ['themisa', 'spase://SMWG/Observatory/THEMIS/B']:
    builder.start('Satellites', {})
    builder.start('Id', {})
    builder.data(sat)
    builder.end('Id')
    builder.start('ResolutionFactor', {})
    builder.data('2')
    builder.end('ResolutionFactor')
    builder.end('Satellites')

builder.start('OutputOptions', {})
builder.start('AllLocationFilters', {})
builder.data('true')
builder.end('AllLocationFilters')

for component in ['X', 'Y', 'Z']:
    builder.start('CoordinateOptions', {})
    builder.start('CoordinateSystem', {})
    builder.data('Gse')
    builder.end('CoordinateSystem')
    builder.start('Component', {})
    builder.data(component)
    builder.end('Component')
    builder.end('CoordinateOptions')

builder.start('MinMaxPoints', {})
builder.data('2')
builder.end('MinMaxPoints')
builder.end('OutputOptions')
builder.end('DataRequest')

request = builder.close()

#print ET.tostring(request)

headers, xml = client.request(endpoint + "locations", "POST",
                              body=ET.tostring(request),
                              headers=requestHeaders)

#print "%s" % xml

doc = ET.fromstring(xml)

result = doc.find('{http://sscweb.gsfc.nasa.gov/schema}Result')

#print ET.tostring(result)

print result.find('{http://sscweb.gsfc.nasa.gov/schema}StatusCode').text

for data in result.findall('{http://sscweb.gsfc.nasa.gov/schema}Data'):
    id = data.find('{http://sscweb.gsfc.nasa.gov/schema}Id').text
    print id
    coords = data.find('{http://sscweb.gsfc.nasa.gov/schema}Coordinates')
    print 'X:'
    for x in coords.findall('{http://sscweb.gsfc.nasa.gov/schema}X'):
        print x.text
    print 'Y:'
    for y in coords.findall('{http://sscweb.gsfc.nasa.gov/schema}Y'):
        print y.text
    print 'Z:'
    for z in coords.findall('{http://sscweb.gsfc.nasa.gov/schema}Z'):
        print z.text
    print 'Time:'
    for time in data.findall('{http://sscweb.gsfc.nasa.gov/schema}Time'):
        print time.text


