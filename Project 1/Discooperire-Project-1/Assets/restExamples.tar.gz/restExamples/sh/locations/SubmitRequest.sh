#!/bin/sh
#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open 
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may 
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or 
#   http://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at 
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the 
# following below this NOSA HEADER, with the fields enclosed by 
# brackets "[]" replaced with your own identifying information: 
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2012 United States Government as represented by the 
# National Aeronautics and Space Administration. No copyright is claimed 
# in the United States under Title 17, U.S.Code. All Other Rights Reserved.
#
# $Id$
#

#
# Test client for the SSC Locator Web services.
#
# Arguments:
#   $1 file containing the XML request
#   $2 
#   $3
#

#set -x
#set -v

userAgent="curlWsExample (`uname -sp`)"

#
# XSLT script to get the /QueryRequest/Description/text() from a 
# Query request file.  
#
getDescription_xslt=/tmp/getDescription.xslt
cat > $getDescription_xslt << EOF
<xsl:transform version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:ssc="http://sscweb.gsfc.nasa.gov/schema">

  <xsl:output method="text" indent="yes" media-type="text/plain" />
  <xsl:template match="/">
    <xsl:for-each select="//ssc:Description" >
      <xsl:value-of select="text()" /><xsl:text> </xsl:text>
    </xsl:for-each>
  </xsl:template>
</xsl:transform>
EOF


#
# Makes an HTTP OPTIONS request and echos the results to standard-out.
#
# Arguments:
#   $1 endpoint URL
#
getWadl() {

    endpointUrl=$1/

    echo "Invoking HTTP OPTIONS ${endpointUrl}"
    curl --user-agent "${userAgent}" --silent --request OPTIONS \
        "${endpointUrl}" | xmllint --format - > ssc.wadl
    echo "WADL was saved in ssc.wadl"
    echo "The contents of ssc.wadl:"
    cat ssc.wadl
    echo
    echo
}



#
# Gets (HTTP GET) the available satellites.
# The result is displayed to standard-out.
#
# Arguments:
#   $1 endpoint URL
#
getObservatories() {

    endpointUrl="$1/observatories"
    echo "Invoking HTTP GET ${endpointUrl}"
    curl --user-agent "${userAgent}" --globoff --silent $traceOption \
         --header "Accept: application/xml" \
        "${endpointUrl}" | xmllint --format -
    echo
    echo
}


#
# Gets (HTTP GET) the available ground stations.
# The result is displayed to standard-out.
#
# Arguments:
#   $1 endpoint URL
#
getGroundStations() {

    endpointUrl="$1/groundStations"
    echo "Invoking HTTP GET ${endpointUrl}"
    curl --user-agent "${userAgent}" --globoff --silent $traceOption \
         --header "Accept: application/xml" \
        "${endpointUrl}" | xmllint --format -
    echo
    echo
}


#
# Performs an HTTP POST with the specified data.
#
# Arguments:
#   $1 endpoint URL
#   $2 name of file containing POST data
#   $3 name of file to store results in
#
doPost() {

    endpointUrl=$1
    postDataFile=$2
    outFile=$3
#    echo "Invoking HTTP POST ${endpointUrl}"
#    echo "With ${postDataFile}"
#    xmllint --format $postDataFile
#    echo "Reply:"
    curl --user-agent "${userAgent}" $traceOption --globoff --silent  \
         --header "Content-Type: application/xml" \
         --header "Accept: application/xml" \
         --data-ascii "@${postDataFile}" \
         "${endpointUrl}" | xmllint --format - > $outFile
#         --include \
#         "${endpointUrl}" > $outFile
}


#
# Gets (HTTP POST) the results of the given query.
# The result is displayed to standard-out.
#
# Arguments:
#   $1 endpoint URL
#   $2 name of file containing query request
#   $3 name of file to contain query result
#
getLocationResult() {

    postData=$2
    resultFile=$3

    grep KmlRequest "${postData}" > /dev/null 2>&1
    if [ $? -eq 0 ]
    then
        endpointUrl="$1/kml"
    else
        endpointUrl="$1/locations"
    fi
    doPost $endpointUrl $postData $resultFile
}


#
# Main part of example.
#

# default parameter values
#
#endpoint=http://sscweb.sci.gsfc.nasa.gov/WS/sscr/2
#endpoint=https://sscweb.sci.gsfc.nasa.gov/WS/sscr/2
#endpoint=http://sscweb-dev.sci.gsfc.nasa.gov/WS/sscr/2
endpoint=https://sscweb-dev.sci.gsfc.nasa.gov/WS/sscr/2
#endpoint=http://localhost:8084/WS/sscr/2
#endpoint=http://localhost:8383/WS/sscr/2


#traceOption="--header 'X-Jersey-Trace-Accept: true'"
#traceOption="--header 'Forwarded: for=192.0.2.60;proto=http;by=203.0.113.43' --header 'Forwarded: for=192.0.2.61,192.0.2.62;proto=http,https;by=203.0.113.44,203.0.113.45'"

if [ $# -lt 1 ]
then
    printf "ERROR: Missing request file\n"
    printf "USAGE: %s requestFilename\n" $0
    exit 1
else
    requestFilename=$1
fi

resultFile=/tmp/getQueryResult$$.xml

#printf "Beginning Test...\n\n"

#getWadl $endpoint

#getObservatories $endpoint

#getGroundStations $endpoint

    description=`xsltproc ${getDescription_xslt} $requestFilename`
    printf "Testing %s (%s)\n" "${requestFilename}" "${description}"
    getLocationResult $endpoint $requestFilename $resultFile
    xmllint --format $resultFile
#    cat $resultFile

#printf "Result file: %s\n" $resultFile
rm -f $resultFile

exit 0
