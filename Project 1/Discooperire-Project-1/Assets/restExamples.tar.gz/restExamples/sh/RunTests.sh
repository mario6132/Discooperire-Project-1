#!/bin/sh
#
# NOSA HEADER START
#
# The contents of this file are subject to the terms of the NASA Open 
# Source Agreement (NOSA), Version 1.3 only (the "Agreement").  You may 
# not use this file except in compliance with the Agreement.
#
# You can obtain a copy of the agreement at
#   docs/NASA_Open_Source_Agreement_1.3.txt
# or 
#   https://sscweb.gsfc.nasa.gov/WebServices/NASA_Open_Source_Agreement_1.3.txt.
#
# See the Agreement for the specific language governing permissions
# and limitations under the Agreement.
#
# When distributing Covered Code, include this NOSA HEADER in each
# file and include the Agreement file at 
# docs/NASA_Open_Source_Agreement_1.3.txt.  If applicable, add the 
# following below this NOSA HEADER, with the fields enclosed by 
# brackets "[]" replaced with your own identifying information: 
# Portions Copyright [yyyy] [name of copyright owner]
#
# NOSA HEADER END
#
# Copyright (c) 2012-2017 United States Government as represented by 
# the National Aeronautics and Space Administration. No copyright is 
# claimed in the United States under Title 17, U.S.Code. All Other 
# Rights Reserved.
#
#

#
# Test client for the SSC REST Web services.
#
# Arguments:
#   $1 optional endpoint URL
#   $2 
#   $3
#

#set -x
#set -v

userAgent="curlWsExample (`uname -sp`)"

#
# Gets the extension of the given filename.
#
# Arguments:
#   $1 filename from which to get the extension.
# 
getFileExtension() {

    echo "${1}" | awk -F. '{print $NF}'
}

PYTHONIOENCODING=utf8
export PYTHONIOENCODING

#
# XSLT script to get the /QueryRequest/Description/text() from a 
# XML Query request file.  
#
getDescription_xslt=/tmp/getDescription.xslt
cat > $getDescription_xslt << EOF
<xsl:transform version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:ssc="http://sscweb.gsfc.nasa.gov/schema">

  <xsl:output method="text" indent="yes" media-type="text/plain" />
  <xsl:template match="/">
    <xsl:for-each select="//ssc:Description" >
      <xsl:value-of select="text()" /><xsl:text> </xsl:text>
    </xsl:for-each>
  </xsl:template>
</xsl:transform>
EOF

#
# Python script to get the /QueryRequest/Description/text() from a 
# JSON Query request file.  
#
getDescription_py=/tmp/getDescription.py
cat > $getDescription_py << EOF
import sys, json;
values = json.load(sys.stdin)
if 'Description' in values:
    sys.stdout.write(values['Description'] + ' ')
else:
    sys.stdout.write(values['Request']['Description'] + ' ')
EOF

#
# Gets the /QueryRequest/Description/text() from a JSON or XML
# request file.
#
# Arguments:
#   $1 name of JSON on XML request file to get the description from.
# 
getDescription() {

    file="${1}"
    type=`getFileExtension "${1}"`
    if [ $type = "xml" ]
    then
        xsltproc ${getDescription_xslt} "${file}"
    else
        cat "${file}" | python ${getDescription_py}
    fi
}

#
# XSLT script to get the /Response/Result/Files/Name/text() from a 
# XML response file.  
#
getFileNames_xslt=/tmp/getFileNames.xslt
cat > $getFileNames_xslt << EOF
<xsl:transform version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:ssc="http://sscweb.gsfc.nasa.gov/schema">

  <xsl:output method="text" indent="yes" media-type="text/plain" />
  <xsl:template match="/">
    <xsl:for-each select="//ssc:Files/ssc:Name" >
      <xsl:value-of select="text()" /><xsl:text> </xsl:text>
    </xsl:for-each>
  </xsl:template>
</xsl:transform>
EOF

#
# Python script to get the /Response/Result/Files/Name/text() from a 
# JSON response file.  
#
getFileNames_py=/tmp/getFileNames.py
cat > $getFileNames_py << EOF
import sys, json;
values = json.load(sys.stdin)
for file in values['Result']['Files'][1]:
    sys.stdout.write(file['Name'] + ' ')
EOF


#
# Gets the /Response/Result/Files/Name/text() from a JSON or XML
# response file.
#
# Arguments:
#   $1 name of JSON on XML file to get file names from.
# 
getFileNames() {

    responseFile="${1}"
    type=`getFileExtension "${1}"`
    if [ $type = "xml" ]
    then
        xsltproc ${getFileNames_xslt} "${responseFile}"
    else
        cat "${responseFile}" | python ${getFileNames_py}
    fi
}


#
# Makes an HTTP request for the WADL and echos the results to 
# standard-out.
#
# Arguments:
#   $1 endpoint URL
#
getWadl() {

    endpointUrl=$1/application.wadl

    echo "Invoking HTTP OPTIONS ${endpointUrl}"
    curl $caCert --user-agent "${userAgent}" --silent \
        "${endpointUrl}" | xmllint --format - > ssc.wadl
    echo "WADL was saved in ssc.wadl"
    echo "The contents of ssc.wadl:"
    cat ssc.wadl
    echo
    echo
}



#
# Gets (HTTP GET) the available satellites.
# The result is displayed to standard-out.
#
# Arguments:
#   $1 endpoint URL
#
getObservatories() {

    endpointUrl="$1/observatories"
    echo "Invoking HTTP GET ${endpointUrl}"
    curl $caCert --user-agent "${userAgent}" --globoff --silent \
         $traceOption --header "Accept: application/xml" \
        "${endpointUrl}" | xmllint --format -
    echo
    echo
}


#
# Gets (HTTP GET) the available ground stations.
# The result is displayed to standard-out.
#
# Arguments:
#   $1 endpoint URL
#
getGroundStations() {

    endpointUrl="$1/groundStations"
    echo "Invoking HTTP GET ${endpointUrl}"
    curl $caCert --user-agent "${userAgent}" --globoff --silent \
         $traceOption --header "Accept: application/xml" \
        "${endpointUrl}" | xmllint --format -
    echo
    echo
}


#
# Performs an HTTP POST with the specified data.
#
# Arguments:
#   $1 endpoint URL
#   $2 name of file containing POST data
#
doPost() {

    endpointUrl=$1
    postDataFile=$2

    reqExt=`getFileExtension "${postDataFile}"`
    requestBasename=`basename "${postDataFile}" ".${reqExt}"`
    rawResultFile="/tmp/${requestBasename}$$.raw"
    resultFile="/tmp/${requestBasename}$$.${reqExt}"
    reqMime="application/${reqExt}"
    curl $caCert --user-agent "${userAgent}" --globoff --silent  \
         $traceOption --header "Content-Type: ${reqMime}" \
         --header "Accept: ${reqMime}" \
         --data-ascii "@${postDataFile}" \
         "${endpointUrl}" > "${rawResultFile}"
    if [ $reqExt = "xml" ]
    then
        xmllint --format "${rawResultFile}" > "${resultFile}"
    else
        python -mjson.tool "${rawResultFile}" > "${resultFile}"
    fi

    rm -f "${rawResultFile}"

    echo "${resultFile}"
}


#
# Gets (HTTP POST) the the specifice resource.
# The result is displayed to standard-out.
#
# Arguments:
#   $1 endpoint URL
#   $2 name of file containing query request
#
getResource() {

    resultFile=`doPost $1 $2`
    
    echo "${resultFile}"
}


#
# Main part of example.
#

# default parameter values
#
#endpoint=https://sscweb.sci.gsfc.nasa.gov/WS/sscr/2
#endpoint=http://sscweb.sci.gsfc.nasa.gov/WS/sscr/2
endpoint=https://sscweb-dev.sci.gsfc.nasa.gov/WS/sscr/2
#endpoint=http://sscweb-dev.sci.gsfc.nasa.gov/WS/sscr/2
#endpoint=http://localhost:8383/WS/sscr/2

caCert="-k"
#caCert="--cacert spdfVH_ca.crt"
#caCert="--cacert ${CURL_CA_BUNDLE}"

#traceOption="--header 'X-Jersey-Trace-Accept: true' --header 'X-Jersey-Tracing-Threshold: SUMMARY'"
#traceOption="--header 'X-Jersey-Trace-Accept: true' --header 'X-Jersey-Tracing-Threshold: TRACE'"
#traceOption="--header 'X-Jersey-Trace-Accept: true' --header 'X-Jersey-Tracing-Threshold: VERBOSE'"



case $# in
1)
    endpoint=$1
    ;;
#2)
#    endpoint=$1
#    dataview=$2
#    ;;
esac

printf "Beginning Tests to %s ...\n\n" $endpoint

#getWadl $endpoint

#getObservatories $endpoint

#getGroundStations $endpoint

numTests=0
numSuccess=0
numFail=0
numUnknown=0
browser=firefox

#resourceTypes="locations conjunctions graphs kml"
resourceTypes="locations conjunctions graphs"

for resourceType in $resourceTypes
do
    for fileType in ".xml" ".json"
    do
        for request in ${resourceType}/requests/*${fileType}
        do
            numTests=`expr $numTests + 1`
            description=`getDescription "${request}"`
            requestBasename=`basename $request`
            printf "Testing %s (%s)\n" "${requestBasename}" \
                "${description}"
            resultFile=`getResource $endpoint/${resourceType} $request`
            if [ -r ${resourceType}/results/$requestBasename ]
            then
                diff ${resourceType}/results/$requestBasename \
                    $resultFile > /dev/null
                if [ $? -ne 0 ]
                then
                    numFail=`expr $numFail + 1`
                    printf ">>>>Results from %s differ from expected results\n" \
                        "${requestBasename}"
                    sdiffFile="${requestBasename}.sdiff"
                    sdiff -w 160 ${resourceType}/results/$requestBasename \
                        $resultFile > "${sdiffFile}"
                    printf ">>>>Results file: %s, sdiff file: %s\n" \
                        "${resultFile}" "${sdiffFile}"
                else
                    numSuccess=`expr $numSuccess + 1`
                    rm -f $resultFile
                fi
            else
                numUnknown=`expr $numUnknown + 1`
                printf "****No known results with which to compare %s with\n" \
                    "${resultFile}"
                resultFileNames=`getFileNames "${resultFile}"`
                if [ "${resultFileNames}X" != "X" ]
                then
                    printf "Manually review the results in ${browser}.\n"
                    ${browser} ${resultFileNames}
                else
                    printf "Manually review the following Response:\n"
                    cat ${resultFile}
                fi
            fi
        done
    done
done


printf "\n\nSummary Test Results\n"
printf "_____________________________________\n"
printf "Total number of tests:         %5d\n" ${numTests}
printf "Number of successful tests:    %5d\n" ${numSuccess}
printf "Number of failed tests:        %5d\n" ${numFail}
printf "Number of indeterminate tests: %5d\n" ${numUnknown}

exit 0
